package com.webserver.servlet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

import com.webserver.http.HttpRequest;
import com.webserver.http.HttpRespond;

public class RegServlet {
	
	public RegServlet() {
		
	}
	
	public void service(HttpRequest request, HttpRespond respond) {
		System.out.println("��ʼ����ע��...");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String nickname = request.getParameter("petname");
		int age = Integer.parseInt(request.getParameter("age"));
		
		RandomAccessFile raf = null;
		boolean existUser = false;
		try {
			raf = new RandomAccessFile("user.dat", "rw");
			for (int i=0; i<raf.length(); i+=100) {
				raf.seek(i);
				byte[] data = new byte[32];
				raf.read(data, 0, 32);
				String existUsername = new String(data, "utf-8").trim();
				System.out.println("Read Username: "+ existUsername);
				if (username.trim().equals(existUsername)){
					existUser = true;
					break;
				}
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (existUser == true) {
			respond.setEntity(new File("webapps/myweb/reg_existuser.html"));
			return;
		}
		
		//System.out.println("��Ϣ��"+username+" "+password+" "+nickname+" "+age);	

		try {
			raf.seek(raf.length());
			byte[] data = username.getBytes("utf-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			data = password.getBytes("utf-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			data = nickname.getBytes("utf-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			raf.writeInt(age);
			respond.setEntity(new File("webapps/myweb/reg_success.html"));
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				raf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
			
		System.out.println("ע��ҵ������ϣ�");
	}
}
