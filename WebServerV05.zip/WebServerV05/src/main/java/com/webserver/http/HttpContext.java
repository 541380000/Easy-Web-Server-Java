package com.webserver.http;

import java.util.*;

public class HttpContext {
	private static Map mimeMapping = new HashMap<String, String>();
	static{
		initMimeMapping();
	}
	private static void initMimeMapping() {
		mimeMapping.put("html", "text/html");
		mimeMapping.put("css", "text/css");
		mimeMapping.put("png", "image/png");
		mimeMapping.put("jpg", "image/jpeg");
		mimeMapping.put("gif", "image/gif");
		mimeMapping.put("js", "application/javascript");
	}
	static public String getContentType(String key) {
		return (String) mimeMapping.get(key);
	}
}
