package com.webserver.servlet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import com.webserver.http.HttpRequest;
import com.webserver.http.HttpRespond;

public class LoginServlet extends HttpServlet{
	public LoginServlet() {
		
	}
	public void service(HttpRequest request, HttpRespond respond) {
		System.out.println("��ʼ������¼ҵ��...");
		RandomAccessFile raf;
		boolean isLoginSuccess = false;
		try {
			raf = new RandomAccessFile("user.dat", "rw");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			byte[] data = new byte[32];
			for (int i=0; i<raf.length(); i+=100) {
				raf.seek(i);
				raf.read(data, 0, 32);
				String readUsername = new String(data, "utf-8").trim();
				if (username.trim().equals(readUsername)) {
					raf.read(data, 0, 32);
					String readPassword = new String(data, "utf-8").trim();
					if (password.trim().equals(readPassword))
						isLoginSuccess = true;
					break;
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (isLoginSuccess) {
			this.forward("/myweb/login_success.html", request, respond);
		}
		else
			this.forward("/myweb/login_fail.html", request, respond);
		
		System.out.println("��¼ҵ������ϣ�");
	}
	
	
	
}
