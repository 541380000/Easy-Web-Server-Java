package com.webserver.http;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class HttpRespond {

	private Socket socket;
	private Map<String, String> header;
	private File entity;
	private byte[] data;
	private int statusCode = 200;
	private String statusReason="OK";

	private OutputStream os;
	
	public HttpRespond(Socket s) throws IOException {
		header = new HashMap<String, String>();
		this.socket = s;
		os = s.getOutputStream();
	}
	public void flush() throws IOException {
		sendStatusLine();
		sendHeaders();
		sendContent();
	}
	
	
	private void sendStatusLine() throws IOException{
		System.out.println("--------���ڷ���״̬��...");
		String line = "HTTP/1.1 200 OK";
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		System.out.println("--------״̬�з�����ϣ�");
	}
	
	private void sendHeaders() throws IOException {
		System.out.println("--------���ڷ�����Ӧͷ...");
		//��Ӧ����
		for (Entry<String, String> h: header.entrySet()) {
			String key = h.getKey(), value = h.getValue();
			String line = key + ": " + value;
			os.write(line.getBytes("ISO8859-1"));
			os.write(13);
			os.write(10);
		}
		
		os.write(13);
		os.write(10);
		System.out.println("--------��Ӧͷ������ϣ�");
	}
	
	private void sendContent() throws IOException {
		System.out.println("--------���ڷ�����Ϣ����...");
		if(entity != null) {
			FileInputStream fis = new FileInputStream(entity);
			int len = -1;
			byte[] data= new byte[8*1024];
			while((len = fis.read(data)) != -1)
				os.write(data, 0, len);
		}
		if (data != null) {
			os.write(data, 0, data.length);
		}
		System.out.println("--------��Ϣ���ķ�����ϣ�");
	}
	
	private void putHeader(String key, String value) {
		header.put(key, value);
	}
	
	
	public void setEntity(File entity) {
		this.entity = entity;
		String filename = entity.getName();
		String[] str = filename.split("[\\.]");
		String houzhui = str[str.length-1];
		//System.out.println("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnname----"+filename);
		putHeader("Content-Type", HttpContext.getContentType(houzhui));
		putHeader("Content-Length", entity.length()+"");
	}
	public void setEntity(byte[] b) {
		this.data = b;
		//System.out.println("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnname----"+filename);
		putHeader("Content-Type", "text/html");
		putHeader("Content-Length", b.length+"");
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusReason() {
		return statusReason;
	}
	public void setStatusReason(String reason) {
		this.statusReason = reason;
	}
	
}
