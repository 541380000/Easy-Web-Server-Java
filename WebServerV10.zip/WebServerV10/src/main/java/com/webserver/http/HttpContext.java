package com.webserver.http;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class HttpContext {
	private static Map mimeMapping = new HashMap<String, String>();
	static{
		initMimeMapping();
		System.out.println("Mapping inited------------------------------------------");
	}
	private static void initMimeMapping() {
		
		try {
			SAXReader reader = new SAXReader();	
			Document doc = reader.read(new File("./conf/web.xml"));
			Element root = doc.getRootElement();
			List<Element> list = root.elements("mime-mapping");
			for(Element e: list) {
				String key = e.element("extension").getTextTrim();
				String value = e.element("mime-type").getTextTrim();
				mimeMapping.put(key, value);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//mimeMapping.put("html", "text/html");
		//mimeMapping.put("css", "text/css");
		//mimeMapping.put("png", "image/png");
		//mimeMapping.put("jpg", "image/jpeg");
		//mimeMapping.put("gif", "image/gif");
		//mimeMapping.put("js", "application/javascript");
	}
	static public String getContentType(String key) {
		return (String) mimeMapping.get(key);
		
	}
}
