package com.webserver.http;

import java.io.*;
import java.net.*;

public class HttpRespond {

	private Socket socket;
	private File entity;
	private int statusCode = 200;
	private String statusReason="OK";

	private OutputStream os;
	
	public HttpRespond(Socket s) throws IOException {
		this.socket = s;
		os = s.getOutputStream();
	}
	public void flush() throws IOException {
		sendStatusLine();
		sendHeaders();
		sendContent();
	}
	
	
	private void sendStatusLine() throws IOException{
		System.out.println("--------���ڷ���״̬��...");
		String line = "HTTP/1.1 200 OK";
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		System.out.println("--------״̬�з�����ϣ�");
	}
	
	private void sendHeaders() throws IOException {
		System.out.println("--------���ڷ�����Ӧͷ...");
		//��Ӧ����
		String line = "Content-Type: text/html";
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		
		//��Ӧ���ݴ�С
		line = "Content-Length: " + entity.length();
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		
		os.write(13);
		os.write(10);
		System.out.println("--------��Ӧͷ������ϣ�");
	}
	
	private void sendContent() throws IOException {
		System.out.println("--------���ڷ�����Ϣ����...");
		FileInputStream fis = new FileInputStream(entity);
		int len = -1;
		byte[] data= new byte[8*1024];
		while((len = fis.read(data)) != -1)
			os.write(data, 0, len);
		System.out.println("--------��Ϣ���ķ�����ϣ�");
	}
	
	public void setEntity(File entity) {
		this.entity = entity;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusReason() {
		return statusReason;
	}
	public void setStatusReason(String reason) {
		this.statusReason = reason;
	}
	
}
