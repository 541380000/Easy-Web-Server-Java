package com.webserver.http;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.*;
import java.util.Map.Entry;

public class HttpRequest {
	/**
	 * �����е���ض���
	 */
	private String method;	//����ʽ
	private String url;		//��������
	private String protocol;	//HTTPЭ��汾��һ��ΪHTTP1.1
	private Socket socket;
	private InputStream is;
	private Map<String, String> headers;
	private StringBuilder content;
	
	/**
	 * ��Ϣͷ��ض���
	 * @throws IOException 
	 */
	
	public HttpRequest(Socket s) throws IOException {
		content = new StringBuilder();
		headers = new HashMap<String, String>();
		try {
			this.socket = s;
			is = socket.getInputStream();
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		this.parseRequestLine();
		this.parseHeaders();
		this.parseContent();
		/*
		System.out.println("======================New Http Request=======================");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		if (is.available()!=0)
		while((c2 = is.read()) != -1) {
			builder.append((char)c2);
			if (c1==13  && c2==10) {
				builder.delete(builder.length()-2, builder.length());
				System.out.println(builder.toString());
				builder.delete(0, builder.length());
			}
			c1 = c2;
		}
		*/
			
	}
	
	//����������
	private void parseRequestLine() throws IOException {	
		System.out.println("------��ʼ����������...");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		int cnt = 0;
		while((c2 = is.read()) != -1) {
			cnt ++;
			builder.append((char)c2);
			if (c1==13  && c2==10) 
				break;
			c1 = c2;
		}
		//if (cnt<2) return;
		String[] str = builder.toString().trim().split("[ ]+");
		System.out.println(builder.toString().trim());
		this.method = str[0];
		this.url = str[1];
		this.protocol = str[2];
		//System.out.println(this.method + this.url + this.protocol);
		System.out.println("------�����н�����ϣ�");
	}
	
	//������Ϣͷ
	private void parseHeaders() throws IOException {
		System.out.println("------��ʼ������Ϣͷ...");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		while((c2 = is.read()) != -1) {
			builder.append((char)c2);
			if (c1==13  && c2==10) {
				if (builder.length() == 2 && (int)builder.charAt(0)==13 && (int)builder.charAt(1)==10)
					break;
				else {
					String[] str = builder.toString().split("[:]");
					builder.delete(0, builder.length());
					String key = str[0].trim(), value = str[1].trim();
					System.out.println("Key: " +key+" Value: "+value);
					headers.put(key, value);
				}
			}
			c1 = c2;
		}
		//for(Entry<String, String> e: headers.entrySet()) 
		//	System.out.println("Key:"+e.getKey() + "\t\t"+"Value:"+e.getValue());
		System.out.println("------��Ϣͷ������ϣ�");
	}
	
	//������Ϣ��
	private void parseContent() throws IOException {
		System.out.println("------��ʼ������Ϣ����...");
		int c1 = -1, c2 = -1;
		if (is.available() != 0)
		while((c2 = is.read()) != -1) {
			content.append((char)c2);
			System.out.println((char)c2);
		}
		System.out.println(1234213);
		System.out.println("------��Ϣ���Ľ�����ϣ�");
	}
	
	public String getURL() {
		return this.url;
	}
	
}
