package com.webserver.core;

import java.io.*;
import java.util.*;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.webserver.servlet.HttpServlet;

public class ServletContext {
	static private Map<String, String> servletMapping= new HashMap<String, String>();
	
	static {
		SAXReader reader = new SAXReader();
		try {
			Document doc = reader.read(new File("./conf/servlets.xml"));
			Element root = doc.getRootElement();
			List<Element> list = root.elements();
			for(Element e: list) {
				String path = e.attribute("path").getStringValue();
				String servletClass = e.attribute("class").getStringValue();
				System.out.println("------->From xml: "+path+" "+servletClass);
				servletMapping.put(path, servletClass);
			}
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}
	
	static public HttpServlet getServletObject(String path) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String name = servletMapping.get(path);
		System.out.println("-------------->Fine servlet: "+name);
		if (name == null) return null;
		Class cls = Class.forName(name);
		return (HttpServlet)(cls.newInstance());
	}
}
