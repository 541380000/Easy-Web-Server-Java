package com.webserver.core;

import java.io.*;
import java.net.*;

import com.webserver.exception.EmptyHttpRequestException;
import com.webserver.http.HttpRequest;
import com.webserver.http.HttpRespond;

public class ClientHandler implements Runnable{
	private Socket socket;
	
	
	
	public ClientHandler(Socket s) {
		this.socket = s;
	}

	public void run(){
		try {
			HttpRequest request = new HttpRequest(socket);
			//System.out.println("-------------------------END of RECV");

			String filename = request.getURL();
			File file = new File("./webapps" + filename);
			System.out.println("./webapps" + filename);
			HttpRespond respond = new HttpRespond(socket);
		
			
			if (!file.exists()) {
				file = new File("./webapps/root/404.html");
				respond.setStatusCode(404);
				respond.setStatusReason("File Not Found!");
				//respond.setEntity(file);
				//System.out.println("File not found!");
			}
			respond.setEntity(file);
			//System.out.println("File found!");
			respond.flush();
			
		}catch(EmptyHttpRequestException e) {
			System.out.println("������ȡ����Ӧ");
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			/**
			 * ����������֮��ر�close
			 */
			try {
				socket.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}
