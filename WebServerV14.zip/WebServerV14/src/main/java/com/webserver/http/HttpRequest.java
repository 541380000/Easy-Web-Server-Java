package com.webserver.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.util.*;
import java.util.Map.Entry;

import com.webserver.exception.EmptyHttpRequestException;

public class HttpRequest {
	/**
	 * �����е���ض���
	 */
	private String method;	//����ʽ
	private String url;		//��������
	private String protocol;	//HTTPЭ��汾��һ��ΪHTTP1.1
	private Socket socket;
	private InputStream is;
	private Map<String, String> headers = new HashMap<String, String>();;
	private StringBuilder content;
	
	/**
	 * ����get�����ύ�ı������ݵõ��Ľ��
	 */
	private String requestURI;
	private String queryString;
	private Map<String, String> parameters = new HashMap<String, String>();
	
	/**
	 * ��Ϣͷ��ض���
	 * @throws IOException 
	 * @throws EmptyHttpRequestException 
	 */
	
	public HttpRequest(Socket s) throws IOException, EmptyHttpRequestException {
		content = new StringBuilder();
		try {
			this.socket = s;
			is = socket.getInputStream();
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		this.parseRequestLine();
		this.parseHeaders();
		this.parseContent();
		/*
		System.out.println("======================New Http Request=======================");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		if (is.available()!=0)
		while((c2 = is.read()) != -1) {
			builder.append((char)c2);
			if (c1==13  && c2==10) {
				builder.delete(builder.length()-2, builder.length());
				System.out.println(builder.toString());
				builder.delete(0, builder.length());
			}
			c1 = c2;
		}
		*/
			
	}
	
	//����������
	private void parseRequestLine() throws IOException, EmptyHttpRequestException {	
		System.out.println("------��ʼ����������...");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		int cnt = 0;
		while((c2 = is.read()) != -1) {
			cnt ++;
			builder.append((char)c2);
			if (c1==13  && c2==10) 
				break;
			c1 = c2;
		}
		if (builder.toString().trim().equals(""))
			throw new EmptyHttpRequestException("Empty HttpRequest");
		//if (cnt<2) return;
		String[] str = builder.toString().trim().split("[ ]+");
		System.out.println(builder.toString().trim());
		this.method = str[0];
		this.url = str[1];
		parseURI();
		this.protocol = str[2];
		//System.out.println(this.method + this.url + this.protocol);
		System.out.println("------�����н�����ϣ�");
	}
	
	//������Ϣͷ
	private void parseHeaders() throws IOException {
		System.out.println("------��ʼ������Ϣͷ...");
		StringBuilder builder = new StringBuilder();
		int c1 = -1, c2 = -1;
		while((c2 = is.read()) != -1) {
			builder.append((char)c2);
			if (c1==13  && c2==10) {
				if (builder.length() == 2 && (int)builder.charAt(0)==13 && (int)builder.charAt(1)==10)
					break;
				else {
					String[] str = builder.toString().split("[:]");
					builder.delete(0, builder.length());
					String key = str[0].trim(), value = str[1].trim();
					System.out.println("Key: " +key+" Value: "+value);
					headers.put(key, value);
				}
			}
			c1 = c2;
		}
		//for(Entry<String, String> e: headers.entrySet()) 
		//	System.out.println("Key:"+e.getKey() + "\t\t"+"Value:"+e.getValue());
		System.out.println("------��Ϣͷ������ϣ�");
	}
	
	//������Ϣ��
	private void parseContent() throws IOException {
		/*
		 * �����Content-Length��Content-Type��˵��������
		 * Content-Type��Ϊ��application/x-www-form-urlencoded
		 * ��˵����������ҳ���ݱ����ύ�����ݣ���ʽ��get������ƴ�ڣ��Ҳ������һ��
		 */

		
		System.out.println("------��ʼ������Ϣ����...");
		int c1 = -1, c2 = -1;
		if (is.available() != 0)
		while(is.available()!=0 && (c2 = is.read()) != -1) {
			System.out.println((char)c2);
			content.append((char)c2);
		}
		String contentString = content.toString();
		System.out.println(contentString);
	
		if (headers.containsKey("Content-Type")) {
			int length = Integer.parseInt(headers.get("Content-Length"));
			String type = headers.get("Content-Type");
			if ("application/x-www-form-urlencoded".equals(headers.get("Content-Type"))){
				String decoded = URLDecoder.decode(contentString, "utf-8");
				String[] paras = decoded.split("\\&");
				for(String s: paras) {
					String[] arr = s.split("=");
					if (arr.length>1) {
						this.parameters.put(arr[0], arr[1]);
					}
					else
						this.parameters.put(arr[0], null);
				}
				for(Entry<String, String> e: this.parameters.entrySet()) {
					System.out.println("Key: "+e.getKey() + " Value: "+e.getValue());
				}
			}
			
		}
		
	
		System.out.println("------��Ϣ���Ľ�����ϣ�");
	}
	
	private void parseURI() throws UnsupportedEncodingException {
		this.requestURI = this.url;
		if (this.url.contains("?")) {
			String[] str = this.url.split("\\?");
			this.requestURI = str[0];
			
			if (str.length > 1) {
				str[1] = URLDecoder.decode(str[1], "utf-8");
				this.queryString = str[1];
			}
			str = this.queryString.split("\\&");
			for(String s: str) {
				String[] arr = s.split("=");
				if (arr.length>1) {
					this.parameters.put(arr[0], arr[1]);
				}
				else
					this.parameters.put(arr[0], null);
			}
			for(Entry<String, String> e: this.parameters.entrySet()) {
				System.out.println("Key: "+e.getKey() + " Value: "+e.getValue());
			}
		}
		
	}

	
	public String getURL() {
		return this.url;
	}
	public String getParameter(String key) {
		return parameters.get(key);
	}
	public String getRequestURI() {
		return this.requestURI;
		
	}

	
}
