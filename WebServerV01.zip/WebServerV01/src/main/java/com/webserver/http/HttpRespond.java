package com.webserver.http;

import java.io.*;
import java.net.*;

public class HttpRespond {

	private Socket socket;
	private File file;
	private OutputStream os;
	
	public HttpRespond(Socket s, File f) throws IOException {
		this.file = f;
		this.socket = s;
		os = s.getOutputStream();
		sendStatusLine();
		sendHeaders();
		sendContent();
	}
	private void sendStatusLine() throws IOException{
		System.out.println("--------���ڷ���״̬��...");
		String line = "HTTP/1.1 200 OK";
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		System.out.println("--------״̬�з�����ϣ�");
	}
	
	private void sendHeaders() throws IOException {
		System.out.println("--------���ڷ�����Ӧͷ...");
		//��Ӧ����
		String line = "Content-Type: text/html";
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		
		//��Ӧ���ݴ�С
		line = "Content-Length: " + file.length();
		os.write(line.getBytes("ISO8859-1"));
		os.write(13);
		os.write(10);
		
		os.write(13);
		os.write(10);
		System.out.println("--------��Ӧͷ������ϣ�");
	}
	
	private void sendContent() throws IOException {
		System.out.println("--------���ڷ�����Ϣ����...");
		FileInputStream fis = new FileInputStream(file);
		int len = -1;
		byte[] data= new byte[8*1024];
		while((len = fis.read(data)) != -1)
			os.write(data, 0, len);
		System.out.println("--------��Ϣ���ķ�����ϣ�");
	}
	
	
}
